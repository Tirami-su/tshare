<?php
require_once '../lib/Db.php';
require_once '../entity/notice.php';

require_once '../lib/phpsocket.io/vendor/autoload.php';
use Workerman\Worker;
use PHPSocketIO\SocketIO;


$onlineUsers = array();		// 全局数组保存所有在线的用户id


// 创建socket.io服务端，监听3120端口
$io = new SocketIO(3120);
// 当有客户端连接时
$io->on('connection', function($socket)use($io){
  	// 保存这个套接字到数组（根据id保存）
  	$socket->on('login', function($id)use($socket) {
  		global $onlineUsers;
  		if(isset($onlineUsers[$id])) {
  			return;
  		}

  		$onlineUsers[$id] = $socket;
  		$socket->uid = $id;
  		
  		echo "登录：". $id."\n";
  	});

  	$socket->on('disconnect', function()use($socket) {
  		global $onlineUsers;
  		if(!isset($onlineUsers[$socket->uid])) {
             return;
        } else {
        	unset($onlineUsers[$socket->uid]);
        }

        echo "退出：". $socket->uid."\n";
  	});
});


// 开启一个http监听端口，通过这个端口可以向指定id的客户端发送消息
$io->on('workerStart', function()use($io){
	$inner_http_worker = new Worker("http://www.haoye.com:3121");
	$inner_http_worker->onMessage = function($http_connection, $data) {
		global $onlineUsers;
		$_POST = $_POST ? $_POST : $_GET;

		/**
		 * 推送的数据格式type=publish&to=id$content=xxx
		 * 也就是说参数$data是一个关联数组，有两个元素
		 * 第一个元素：'type'    = "publish"
		 * 第二个元素：'data' = '数据'(这是一个数组)
		 * 数组中包含了一个消息(notice)的所有信息
		 */
		global $io;
		$data = $_POST['data'];
		$to = $data['to'];		// 接收者

		if($to === NULL) {
			// 如果是向所有用户发送消息
			foreach ($onlineUsers as $value) {
				// 先对所有在线用户发送
				$value->emit('new_msg', json_encode($data['content']));
			}

			// 再将不在线的用户进行暂存
			
		}

		if($to && !isset($onlineUsers[$to])) {
			// 用户不在线，将消息暂存在数据库
			$notice = new notice();
            $notice->set($data);
            $db = new Db();
            $flag = $db->insert("notice", $notice);
            return $http_connection->send('offline');
		}


		$data = $_POST['data'];
		$to = $data['address'];		// 获取收件人

		$flag = false;
		// http接口返回，如果用户离线，先将消息保存到信箱，等用户上线再发送
        if($to && !isset($onlineUsers[$to])){
            // 保存到信箱（数据库中）
            $notice = new notice();
            $notice->set($data);
            $db = new Db();
            $flag = $db->insert("notice", $notice);
            return $http_connection->send('offline');
        }else{
            $flag = true;
        }

		if($to) {
			// 如果有指定的id，则向该id所对应的客户端发送消息
			$onlineUsers[$to]->emit('new_msg', $_POST['data']);
		} else {
			// 向所有客户端发送消息
			$io->emit('new_msg', $_POST['data']);
		}

		if($flag) {
            return $http_connection->send('ok');
		} else {
			return $http_connection->send('fail');
		}
	};
	$inner_http_worker->listen();
});

Worker::runAll();
?>